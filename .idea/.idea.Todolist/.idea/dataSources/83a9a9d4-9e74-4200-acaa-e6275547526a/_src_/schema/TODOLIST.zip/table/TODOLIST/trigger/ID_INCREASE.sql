CREATE TRIGGER ID_INCREASE
BEFORE INSERT
  ON TODOLIST
FOR EACH ROW
  begin
    select increase_sequence.nextval into:New.id from dual;
  end;
/
